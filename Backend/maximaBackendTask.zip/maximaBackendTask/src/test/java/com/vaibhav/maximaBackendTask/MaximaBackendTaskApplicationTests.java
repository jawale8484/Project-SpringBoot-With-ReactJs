package com.vaibhav.maximaBackendTask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaximaBackendTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
